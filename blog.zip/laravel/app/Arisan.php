<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Arisan extends Model
{
    //
}
