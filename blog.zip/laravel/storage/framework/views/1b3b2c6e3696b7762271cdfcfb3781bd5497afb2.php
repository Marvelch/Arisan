<?php $__env->startSection('nav_menu'); ?>
  <ul class="list-unstyled">
    <li class="active"><a href="<?php echo e(route('home')); ?>"> <i class="icon-home"></i>Dashboard </a></li>
    <li><a href="<?php echo e(route('profile')); ?>"> <i class="fa fa-id-card-o"></i>Profile </a></li>
    <li><a href="<?php echo e(route('donation')); ?>"> <i class="fa fa-credit-card "></i>Donasi </a></li>
    <li><a href="<?php echo e(route('winner')); ?>"> <i class="fa fa-users"></i>Group</a></li>
  </ul><span class="heading">Layanan</span>
  <ul class="list-unstyled">
    <li> <a href="<?php echo e(route('contact')); ?>"> <i class="icon-mail"></i>Kontak </a></li>
  </ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('sub_content'); ?>
<div class="content-inner">
          <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">Dashboard</h2>
            </div>
          </header>
          <!-- Dashboard Counts Section-->
          <section class="dashboard-counts no-padding-bottom">
            <div class="container-fluid">
              <div class="row bg-white has-shadow">
              <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
          <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
          </ol>
          <div class="carousel-inner">
            <div class="carousel-item active">
              <img class="d-block w-100" src="https://miro.medium.com/max/7204/1*6896ASu1A0nqXyhwjxWgTA.png" alt="First slide" style="height: 25rem;">
            </div>
            <div class="carousel-item">
              <img class="d-block w-100" src="https://miro.medium.com/max/9600/1*WBblwZRtd8yxDi19rLaj6A.png" alt="Second slide" style="height: 25rem;">
            </div>
            <div class="carousel-item">
              <img class="d-block w-100" src="https://miro.medium.com/max/9600/1*kBkI057hByC8ODB4WV1PlQ.png" alt="Third slide" style="height: 25rem;">
            </div>
          </div>
          <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
          </a>
          <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
          </a>
        </div>
                <!-- Item -->
                <?php $__currentLoopData = $counts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-xl-3 col-sm-6">
                  <div class="item d-flex align-items-center">
                    <div class="icon bg-violet"><i class="icon-user"></i></div>
                    <div class="title"><span>Data</br>Peserta</span>
                      <div class="progress">
                        <div role="progressbar" style="width: <?php echo e($count); ?>%; height: 4px;" aria-valuenow="<?php echo e($count); ?>" aria-valuemin="0" aria-valuemax="100" class="progress-bar bg-violet"></div>
                      </div>
                    </div>
                    <div class="number"><strong><?php echo e($count); ?></strong></div>
                  </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $count_group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count_g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!-- Item -->
                <div class="col-xl-3 col-sm-6">
                  <div class="item d-flex align-items-center">
                    <div class="icon bg-red"><i class="icon-padnote"></i></div>
                    <div class="title"><span>Data<br>Group</span>
                      <div class="progress">
                        <div role="progressbar" style="width: <?php echo e($count_g); ?>%; height: 4px;" aria-valuenow="<?php echo e($count_g); ?>" aria-valuemin="0" aria-valuemax="100" class="progress-bar bg-red"></div>
                      </div>
                    </div>
                    <div class="number"><strong><?php echo e($count_g); ?></strong></div>
                  </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $ends; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $end): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!-- Item -->
                <div class="col-xl-3 col-sm-6">
                  <div class="item d-flex align-items-center">
                    <div class="icon bg-green"><i class="icon-bill"></i></div>
                    <div class="title"><span>Peserta<br>Selesai</span>
                      <div class="progress">
                        <div role="progressbar" style="width: <?php echo e($end); ?>%; height: 4px;" aria-valuenow="<?php echo e($end); ?>" aria-valuemin="0" aria-valuemax="100" class="progress-bar bg-green"></div>
                      </div>
                    </div>
                    <div class="number"><strong><?php echo e($end); ?></strong></div>
                  </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <!-- Item -->
                <div class="col-xl-3 col-sm-6">
                  <div class="item d-flex align-items-center">
                    <div class="icon bg-orange"><i class="icon-check"></i></div>
                    <div class="title"><span>Laporan</span>
                      <div class="progress">
                        <div role="progressbar" style="width: 50%; height: 4px;" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" class="progress-bar bg-orange"></div>
                      </div>
                    </div>
                    <div class="number"><strong>1</strong></div>
                  </div>
                </div>
              </div>
            </div>
          </section>
          <!-- Dashboard Header Section    -->
          <section class="dashboard-header">
            <div class="container-fluid">
              <div class="row">
                <!-- Statistics -->
                <div class="statistics col-lg-12">
                <div class="card text-center">
                    <div class="card-header">
                      <h5>Buat Group Arisan</h5>
                    </div>
                    <div class="card-body">
                      <p class="card-text">Temukan layanan arisan online terpercaya & terbaik hanya bookingbuku.com </p>
                      <a href="<?php echo e(route('group')); ?>" class="btn btn-primary">Buat Group</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sub_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Arisan\blog\resources\views/home.blade.php ENDPATH**/ ?>