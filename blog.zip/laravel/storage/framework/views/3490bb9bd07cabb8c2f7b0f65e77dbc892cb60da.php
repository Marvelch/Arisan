

<?php $__env->startSection('nav_menu'); ?>
  <ul class="list-unstyled">
    <li><a href="<?php echo e(route('home')); ?>"> <i class="icon-home"></i>Dashboard </a></li>
    <li><a href="<?php echo e(route('profile')); ?>"> <i class="fa fa-id-card-o"></i>Profile </a></li>
    <li><a href="<?php echo e(route('donation')); ?>"> <i class="fa fa-credit-card "></i>Donasi </a></li>
    <li class="active"><a href="<?php echo e(route('winner')); ?>"> <i class="fa fa-users"></i>Group</a></li>
  </ul><span class="heading">Layanan</span>
  <ul class="list-unstyled">
    <li> <a href="<?php echo e(route('contact')); ?>"> <i class="icon-mail"></i>Kontak </a></li>
  </ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('sub_content'); ?>
<div class="content-inner">
          <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">Group Arisan</h2>
            </div>
          </header>
          <section class="forms"> 
            <div class="container-fluid">
              <?php if(Session::has('message')): ?>
                <div class="alert <?php echo e(Session::get('alert alert-secondary', 'alert-info')); ?>">
                  <strong><?php echo e(Session::get('message')); ?></strong>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>   
                <?php endif; ?>
              <div class="row">
                <!-- Pemenang Arisan Terakhir-->
                <div class="col-sm-6">
                  <div class="card">
                    <div class="card-header d-flex align-items-center">
                    Semua Group
                    </div>
                    <div class="card-body">
                      <!-- <p>Lorem ipsum dolor sit amet consectetur.</p> -->
                      <form>
                      <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-group">
                        <table class="table table-borderless text-left">
                          <tbody>
                            <tr>
                              <th><a href="<?php echo e(url('view/'.$group->id.'/group_')); ?>"><i class="fa fa-external-link"></i><span class="ml-3"><?php echo e($group->groups_name); ?></span></a></th>
                              <td></td>
                            </tr>
                          </tbody>
                        </table>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </form>
                      <?php echo e($groups->links()); ?>

                    </div>
                  </div>
                </div>
                <!-- Horizontal Form-->
                <div class="col-lg-6">
                <div class="card">
                  <div class="card-header">
                    Buat Group
                  </div>
                  <div class="card-body">
                    <h5 class="card-title">Arisan Bookingbook.my.id</h5>
                    <p class="card-text">Temukan cara yang lebih sederhan untuk melakukan arisan.</p>
                    <a href="#" class="btn btn-primary">Go somewhere</a>
                  </div>
                </div>
                </div>
              </div>
            </div>
          </section>
          
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sub_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Arisan\blog\resources\views/winner.blade.php ENDPATH**/ ?>