<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404 <?php echo e(config('app.name', 'Laravel')); ?></title>
</head>
<body style="background-image: url('img/Not Found.jpg');
background-repeat: no-repeat;
background-position: 50% 40%;
background-attachment: fixed;
background-size: 80%;">

</body>
</html>
<?php /**PATH C:\xampp\htdocs\Arisan\blog\resources\views/not_found.blade.php ENDPATH**/ ?>