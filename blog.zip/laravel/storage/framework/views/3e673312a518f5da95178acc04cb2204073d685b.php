<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404 <?php echo e(config('app.name', 'Laravel')); ?></title>
</head>
<body style="background-image: url('img/404.png');
background-repeat: no-repeat;
background-position: center center;
background-attachment: fixed;
background-size: auto;">

</body>
</html>
<?php /**PATH C:\xampp\htdocs\Arisan\blog\resources\views/404.blade.php ENDPATH**/ ?>