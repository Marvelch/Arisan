

<?php $__env->startSection('nav_menu'); ?>
<ul class="list-unstyled">
            <li><a href="<?php echo e(route('home')); ?>"> <i class="icon-home"></i>Dashboard </a></li>
            
            <li><a href="<?php echo e(route('profile')); ?>"> <i class="fa fa-id-card-o"></i>Profile </a></li>
            <li><a href="<?php echo e(route('donation')); ?>"> <i class="fa fa-credit-card "></i>Donasi </a></li>
            <li><a href="<?php echo e(route('winner')); ?>"> <i class="fa fa-users"></i>Group</a></li>
          </ul><span class="heading">Layanan</span>
          <ul class="list-unstyled">
            <li  class="active"><a href="#"> <i class="icon-mail"></i>Kontak </a></li>
          </ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('sub_content'); ?>
<div class="content-inner">
          <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">Kontak</h2>
            </div>
          </header>
          <section class="dashboard-counts no-padding-bottom">
            <div class="container-fluid">
              <div class="row bg-white has-shadow">
                <div class="col-sm-6">
                <div class="card-body">
                      <form>
                        <div class="form-group pt-3">
                          <label class="form-control-label">Email</label>
                          <input type="email" class="form-control">
                        </div>
                        <div class="form-group">
                          <label class="form-control-label">Subyek</label>
                          <input type="email" class="form-control">
                        </div>
                        <div class="form-group">       
                          <label class="form-control-label">Pesan</label>
                          <textarea name="" id="" cols="30" rows="5" class="form-control"></textarea>
                        </div>
                        <div class="form-group">       
                          <input type="submit" value="Kirim" class="btn btn-primary">
                        </div>
                      </form>
                    </div>
                </div>
                <div class="col-sm-5">
                <div class="card-body">
                      <form>
                      <div class="card-deck">
                        <div class="card text-center">
                            <img class="card-img-top" src="img/no_photo.png" alt="Card image cap">
                            <div class="card-body">
                            <!-- <h5 class="card-title">Email</h5> -->
                            <p class="card-text">Cs@bookingbook.my.id</p>
                            </div>
                        </div>
                      </form>
                    </div>
                </div>
              </div>
            </div>
          </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sub_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Arisan\blog\resources\views/contact.blade.php ENDPATH**/ ?>