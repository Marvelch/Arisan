

<?php $__env->startSection('nav_menu'); ?>
  <ul class="list-unstyled">
    <li><a href="<?php echo e(route('home')); ?>"> <i class="icon-home"></i>Dashboard </a></li>
    <li><a href="<?php echo e(route('profile')); ?>"> <i class="fa fa-id-card-o"></i>Profile </a></li>
    <li class="active"><a href="<?php echo e(route('donation')); ?>"> <i class="fa fa-credit-card "></i>Donasi </a></li>
    <li><a href="<?php echo e(route('winner')); ?>"> <i class="fa fa-users"></i>Group</a></li>
  </ul><span class="heading">Layanan</span>
  <ul class="list-unstyled">
    <li> <a href="<?php echo e(route('contact')); ?>"> <i class="icon-mail"></i>Kontak </a></li>
  </ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('sub_content'); ?>
<div class="content-inner">
          <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">Donasi</h2>
            </div>
          </header>
          <section class="projects padding-top">
            <div class="container-fluid">
              <!-- Project-->
              <div class="project">
                <div class="row bg-white has-shadow">
                  <div class="left-col col-lg-6 d-flex align-items-center justify-content-between">
                    <div class="project-title d-flex align-items-center">
                      <div class="text text-center">
                        <h3 class="h4">Layanan Donasi</h3><small>Bantu kami untuk terus mengembangkan layanan.</small>
                      </div>
                    </div>
                  </div>
                  <div class="pt-1 col-lg-6 d-flex align-items-center">
                  <select class="form-control form-control-sm" onchange="payments()" id="selected_payments" onclick="myFunction()">
                    <option>Pilih Metode Donasi</option>
                    <option value="paypal">Paypal</option>
                    <option value="gopay">Go - pay</option>
                    </select>
                    </div>
                  </div>
                </div>
              </div>
            </div>
              <!-- Modal Go-pay-->
            <div class="modal fade" id="GopayModal" tabindex="-1" role="dialog" aria-labelledby="GopayModal" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="GopayModal">Go-pay</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body text-center">
                    <ul>
                      <p>No Go-pay bookingbook.my.id</p>
                      <br>
                      <h3>082217797018 / 083878337954</h3>
                      <br>
                      <p class="text-rigth">Terima Kasih</p>
                    </ul>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                  </div>
                </div>
              </div>
            </div>
            <!-- Modal Paypal -->
            <div class="modal fade" id="PaypalModal" tabindex="-1" role="dialog" aria-labelledby="PaypalModal" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="PaypalModal">Paypal</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body text-center">
                    <ul>
                      <p>Email Paypal bookingbook.my.id</p>
                      <br>
                      <h3>mr.marvel.christevan@gmail.com</h3>
                      <br>
                      <p class="text-rigth">Terima Kasih</p>
                    </ul>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                  </div>
                </div>
              </div>
            </div>
          </section>

<script>
    function payments()
      {
        payment = document.getElementById("selected_payments").value;
        
        if(payment == "gopay")
        {
          $("#GopayModal").modal('toggle'); //see here usage
        }else{
          $("#PaypalModal").modal('toggle');
        }
      }
    

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sub_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Arisan\blog\resources\views/donasi.blade.php ENDPATH**/ ?>